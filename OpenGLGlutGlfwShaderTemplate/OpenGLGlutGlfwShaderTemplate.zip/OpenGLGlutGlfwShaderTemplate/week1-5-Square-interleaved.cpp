
///////////////////////////////////////////////////////////////////////
//
// Square.cpp
// Add color Interleaved using the same vbo
////use one vertex buffer object for both vertex position and color
///////////////////////////////////////////////////////////////////////


using namespace std;

#include "stdlib.h"
#include "time.h"
#include <GL/glew.h>
#include <GL/freeglut.h> 
#include "prepShader.h"
#include "glm\glm.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include <array>



GLuint vertices_vbo, colors_vbo;


GLfloat vertices[] = {
	//( x     y     z )  (r     g    b  )
   -0.9f,   0.9f,  0.0f,  1.0f, 0.0f, 0.0f,
	0.9f,   0.9f,  0.0f,  0.0f, 1.0f, 0.0f,
	0.9f,  -0.9f,  0.0f,  0.0f, 0.0f, 1.0f,
   -0.9f,  -0.9f,  0.0f,  0.0f, 1.0f, 1.0f
};

//GLfloat colors[] = {
//	1.0f, 0.0f, 0.0f,
//	0.0f, 1.0f, 0.0f,
//	0.0f, 0.0f, 1.0f,
//	0.0f, 1.0f, 1.0f
//};

#define BUFFER_OFFSET(x)  ((const void*) (x))
static unsigned int
program,
vertexShaderId,
fragmentShaderId;


void init(void)
{

	// Create shader program executable.

	vertexShaderId = setShader((char*)"vertex", (char*)"square.vert");
	fragmentShaderId = setShader((char*)"fragment", (char*)"square.frag");
	program = glCreateProgram();
	glAttachShader(program, vertexShaderId);
	glAttachShader(program, fragmentShaderId);
	glLinkProgram(program);
	glUseProgram(program);


	//use one vertex buffer object for both vertex position and color
	vertices_vbo = 0;
	glGenBuffers(1, &vertices_vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vertices_vbo);
	glBufferData(GL_ARRAY_BUFFER, 24 * sizeof(GLfloat), vertices, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (void*)0);
	glEnableVertexAttribArray(0);

	//colors_vbo = 0;
	//glGenBuffers(1, &colors_vbo);
	//glBindBuffer(GL_ARRAY_BUFFER, colors_vbo);
	
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (void*)(sizeof(float) * 3));
	glEnableVertexAttribArray(1);

	glClearColor(1.0, 1.0, 1.0, 1.0); // white background

}


//---------------------------------------------------------------------
//
// display
//

void
display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);

	//Ordering the GPU to start the pipeline
	glDrawArrays(GL_LINE_LOOP, 0, 4);

	glFlush();
}


void idle()
{
	//glutPostRedisplay();
}

// Keyboard input processing routine.
void keyInput(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 27:
		exit(0);
		break;
	default:
		break;
	}
}

//---------------------------------------------------------------------
//
// main
//

int main(int argc, char** argv)
{
	//Before we can open a window, theremust be interaction between the windowing systemand OpenGL.In GLUT, this interaction is initiated by the following function call :
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);

	//if you comment out this line, a window is created with a default size
	glutInitWindowSize(512, 512);

	//the top-left corner of the display
	glutInitWindowPosition(0, 0);

	glutCreateWindow("Hello World");

	glewInit();	//Initializes the glew and prepares the drawing pipeline.

	init();

	//If there are events in the queue, our program responds to them through functions
	//called callbacks.A callback function is associated with a specific type of event.
	//A display callback is generated when the application programm or the
	//operating system determines that the graphics in a window need to be redrawn.
	glutDisplayFunc(display);

	glutIdleFunc(idle);
	glutKeyboardFunc(keyInput);

	//begin an event-processing loop
	glutMainLoop();



}
